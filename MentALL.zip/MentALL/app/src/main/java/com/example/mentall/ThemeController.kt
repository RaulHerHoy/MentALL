package com.example.mentall

import androidx.compose.runtime.mutableStateOf

object ThemeController {
    // false = claro | true = oscuro
    val darkTheme = mutableStateOf(false)
}
